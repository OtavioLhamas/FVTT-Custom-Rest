import LongRestDialog from "../../systems/dnd5e/module/apps/long-rest.js";

export default class HDLongRestDialog extends LongRestDialog {
	static async hdLongRestDialog({actor}={}) {
		
	}
}