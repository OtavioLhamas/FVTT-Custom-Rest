import ShortRestDialog from "../../systems/dnd5e/module/apps/short-rest.js";

/**
 * A helper Dialog subclass for rolling Hit Dice on short rest
 * @extends {Dialog}
 */
export default class HDShortRestDialog extends ShortRestDialog {
	static async hdShortRestDialog({actor}={}) {
		
	}
}